import './list.css'
export default function List(props){


    console.log(props)
    return(
        <>
        <h1>{props.item}</h1>
        </>
    )
}