import { useState } from 'react'
import './App.css'
import Login from './pages/login'
import Display from './pages/display'
import { Route, Router, Routes } from 'react-router'

function App() {
  const [data, setData] = useState()

  
  return (
    <>
    <Routes>
    <Route path='/' element={<Login/>}/>
    <Route path='/d' element={<Display/>}/>
    </Routes>
    
     
  
  
    </>
  )
}

export default App
