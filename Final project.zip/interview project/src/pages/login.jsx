import {useHistory} from "react"

export default function Login(){


    const clickHandler = async()=> {
        fetch("https://f88cebef-2139-459c-8447-11f5ccebfcb4.mock.pstmn.io/login", {
          method : "POST"
        })
        .then((res)=>{return res.json()})
        .then((data)=>{console.log(data.response)
            
          window.localStorage.setItem("data", data.response)
          window.location.replace("https://fantastic-space-fiesta-v66wrgg75457h6gjg-5173.app.github.dev/d")
          

        })
        .catch((err)=>{
          console.log(err.message)
        })
    }


    return(
        <>
        <button onClick={clickHandler}>Login</button>
        </>
    )
}