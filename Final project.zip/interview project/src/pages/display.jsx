import { useEffect, useState } from "react"
import List from "../component/list";
import './display.css'

export default function Display(){

    const [data, setData] = useState([]);

    const getData = async()=>{
    
    

    await setInterval(()=>{
   
       fetch("https://f88cebef-2139-459c-8447-11f5ccebfcb4.mock.pstmn.io/getdata", {
         method : "GET",
         headers : {
           'auth-token' : window.localStorage.getItem("data"),
            'Content-Type' : 'application/json'
         }
       })
       .then((res)=>res.json())
       .then((data)=>{console.log(data.response)
        setData(data.response)
       })
       .catch((err)=>{
         console.log(err.message)
       })
 
    }, 2000)

 
 }


   return(
    <>
      <div>
      <button onClick={getData}>GetData</button>
      <h1 className="da">
        {data.map((item)=>{
            return(
                <List item={item}/>
            )
        })}
      </h1>
      </div>
    </>
)
}